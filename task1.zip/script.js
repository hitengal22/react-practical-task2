$(document).ready(function () {
  var scroll_pos = 0;
  if ($(document).scrollTop() > 50) {
    $('header').addClass('bg-white');
  }
  $(document).scroll(function () {
    scroll_pos = $(this).scrollTop();
    if (scroll_pos > 50) {
      $('header').addClass('bg-white');
    } else {
      $('header').removeClass('bg-white');
    }
  });

  var $owl = $('.owl-carousel');

  $owl.children().each(function (index) {
    $(this).attr('data-position', index); // NB: .attr() instead of .data()
  });

  $owl.owlCarousel({
    margin: 15,
    width: 220,
    center: true,
    loop: false,
    startPosition: 2,
    items: 8,
    nav: false,
    dots: false,
    responsive: {
      0: {
        items: 2
      },
      600: {
        items: 2
      },
      1000: {
        items: 8
      }
    }
  });

  $(document).on('click', '.owl-item>div', function () {
    // see https://owlcarousel2.github.io/OwlCarousel2/docs/api-events.html#to-owl-carousel
    var $speed = 300; // in ms
    $owl.trigger('to.owl.carousel', [$(this).data('position'), $speed]);
  });

  /* clear text */
  $('form').on('click', '.form-text + .clear-text', function (e) {
    e.preventDefault();
    console.log('clear text.');
    $(this).prev('input').val('');
    return false;
  });

  $('form').on('focus blur keyup onchange', '.form-text:not([required])', function (e) {
    e.preventDefault();
    if ($(this).val().length) {
      $('.clear-text').show();
    } else {
      $('.clear-text').hide();
    }
  });
  $('form').on(
    'click',
    '.clear-text',
    function (e) {
      e.preventDefault();
      console.log('remove valid-text.');
      $('.form-text').removeClass('valid-text').val('');
      $(this).hide()
      return false;
    }
  );
});
